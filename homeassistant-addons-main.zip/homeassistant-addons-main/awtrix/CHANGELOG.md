# Changelog

## [1.0.1] - 2022-12-27

- The good old permission issues....

## [1.0.0] - 2022-12-27

Changes from forked repo:

- Removed stable/beta choice - development has stopped and stable is newer
- Added multiple arch back
- Updated base images
- Changed to openjdk8 - fulfills the needs of AWTRIX and builds on all archs

---

Original CHANGELOG.md below

---

version 0.2.6 disabled hassio-detexction from awtrix server

version 0.2.5 tested with Beta 2025 removed support for Raspi (sorry about that) because there is no openjdk11-jre apk for it

version 0.2.4 tested with Beta 2025 export to /config folder

version 0.2.3 tested with Beta 2024

version 0.1.8 version with new 2.x beta server

version 0.1.5 version with new 2.0 stable server

version 0.0.8 use serial-ports from your host

version 0.0.7: configure "lang"
