# Changelog

## [0.8.0] - 2021-02-26

- Introduce `eval` configuration option (see _Documentation_ for more)

## [0.7.0] - 2021-02-13

- Added some more ports to be possibly exposed

## [0.6.0] - 2021-02-12

- Use Pre-build containers (no more unused docker images, yay).  
  **🚨 !!Important Update Notice!! 🚨**  
  The Update progress might fail when the installed version is <1.4.0.  
  Copy your _Configuration_ to your clipboard and Uninstall/Install manually.

## [0.5.0] - 2021-01-04

- Fix two superflous warnings

## [0.4.0] - 2020-12-30

- Change from sha image tag to v5.1.0

## [0.3.0] - 2020-12-30

- Added some ports for free use (e.g. `simple api`)

## [0.2.0] - 2020-12-30

- Fix permission bug in dockerfile

## [0.1.0] - 2020-12-30

- Initial release
