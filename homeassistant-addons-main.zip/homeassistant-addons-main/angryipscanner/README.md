# Home Assistant Add-on: Angry IP Scanner

<a href='https://ko-fi.com/MaxWinterstein' target='_blank'><img height='35' style='border:0px;height:46px;' src='https://az743702.vo.msecnd.net/cdn/kofi3.png?v=0' border='0' alt='Buy Me a Coffee at ko-fi.com'></a>

Wraps the well known [Angry IP Scanner](https://angryip.org/) to make it usable as Add-on.

![screenshot](https://github.com/MaxWinterstein/homeassistant-addons/blob/main/angryipscanner/screenshot.png?raw=true)

Most of this add-on code is shamelessly stolen from https://github.com/home-assistant/addons/tree/master/deconz. Thanks ✌️
