# Changelog

## 1.1.3 // 07.12.2022

- Internal: Build image also for ARMv7

## 1.1.2 // 01.12.2022

- Fix permission error - part 3

## 1.1.1 // 01.12.2022

- Fix permission error - part 2

## 1.1.0 // 29.11.2022

- Fix permission error

## 1.0.0 // 28.11.2022

- Change to ghcr

## 0.1.0

- Initial release
