# DEPRECATED

## I would no longer suggest to use this. There are way better alternatives out there, e.g. https://github.com/alexbelgium/hassio-addons/tree/master/portainer

---

⚠️⚠️⚠️⚠️⚠️

This is a complete copy of https://github.com/hassio-addons/addon-portainer/tree/v1.5.2

As the current version (`2.0.0` at this time) of this addon has problems with starting containers this clone simply provides easy access to `1.5.2`.

See https://community.home-assistant.io/t/portainer-v2-6-2-unable-to-start-containers/332356 or https://github.com/hassio-addons/addon-portainer/issues/127 for more.

All credits belong to the original creators.

⚠️⚠️⚠️⚠️⚠️

---

# Home Assistant Community Add-on: Portainer

[![Release][release-shield]][release] ![Project Stage][project-stage-shield] ![Project Maintenance][maintenance-shield]

[![Discord][discord-shield]][discord] [![Community Forum][forum-shield]][forum]

[![Sponsor Frenck via GitHub Sponsors][github-sponsors-shield]][github-sponsors]

[![Support Frenck on Patreon][patreon-shield]][patreon]

Manage your Docker environment with ease.

## About

Portainer is an open-source lightweight management UI which allows you to
easily manage your a Docker host(s) or Docker swarm clusters.

It has never been so easy to manage Docker. Portainer provides a detailed
overview of Docker and allows you to manage containers, images, networks and
volumes.

## WARNING

The Portainer add-on is really powerful and gives you virtually access to
your whole system. While this add-on is created and maintained with care and
with security in mind, in the wrong or inexperienced hands,
it could damage your system.

![Portainer screenshot][screenshot]

[discord-shield]: https://img.shields.io/discord/478094546522079232.svg
[discord]: https://discord.me/hassioaddons
[forum-shield]: https://img.shields.io/badge/community-forum-brightgreen.svg
[forum]: https://community.home-assistant.io/t/home-assistant-community-add-on-portainer/68836?u=frenck
[github-sponsors-shield]: https://frenck.dev/wp-content/uploads/2019/12/github_sponsor.png
[github-sponsors]: https://github.com/sponsors/frenck
[maintenance-shield]: https://img.shields.io/maintenance/yes/2021.svg
[patreon-shield]: https://frenck.dev/wp-content/uploads/2019/12/patreon.png
[patreon]: https://www.patreon.com/frenck
[project-stage-shield]: https://img.shields.io/badge/project%20stage-production%20ready-brightgreen.svg
[release-shield]: https://img.shields.io/badge/version-v2.0.0-blue.svg
[release]: https://github.com/hassio-addons/addon-portainer/tree/v2.0.0
[screenshot]: https://github.com/hassio-addons/addon-portainer/raw/main/images/screenshot.png
