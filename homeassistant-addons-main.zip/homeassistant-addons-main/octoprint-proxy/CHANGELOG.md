# Changelog

## [1.0.2] - 2022-12-16

- Change to prebuild images

## [1.0.1] - 2022-12-16

- Fix pid issue - thanks @0nikola1

## [1.0.0] - 2021-01-03

- Initial release
