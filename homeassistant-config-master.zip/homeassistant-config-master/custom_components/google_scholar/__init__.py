"""The google_scholar sensor component."""
