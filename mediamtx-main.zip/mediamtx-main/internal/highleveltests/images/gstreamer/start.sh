#!/bin/sh -e

exec gst-launch-1.0 $@ 2>&1
