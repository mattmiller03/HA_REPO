#ifndef __BASE64_H__
#define __BASE64_H__

char* base64_decode(const char *data);

#endif
