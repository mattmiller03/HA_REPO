const sensorType = {
  // Param type
  BATTERY_PERCENTAGE: 1101,
}

exports.SensorType = sensorType
exports.supportedSensorTypes = Object.values(sensorType)
