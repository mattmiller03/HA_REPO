const yaml = require('js-yaml')
const fs = require('fs')
const get = require('get-value')
const winston = require('winston')

class Config {
  eufyUsername
  eufyPassword

  mqttUrl
  mqttUsername
  mqttPassword
  mqttKeepalive

  haOffDelay

  constructor () {
    let config
    try {
      config  = yaml.load(fs.readFileSync('./data/config.yml', 'utf8'));
    } catch (e) {
      winston.error('Cannot read config.yml')
      throw e
    }

    this.eufyUsername = get(config, 'eufy.username')
    this.eufyPassword = get(config, 'eufy.password')

    this.mqttUrl = get(config, 'mqtt.url')
    this.mqttUsername = get(config, 'mqtt.username')
    this.mqttPassword = get(config, 'mqtt.password')
    this.mqttKeepalive = parseInt(get(config, 'mqtt.keepalive', { default: 60 }))

    this.haOffDelay = parseInt(get(config, 'home_assistant.off_delay', { default: 5 }))

    if (
      typeof this.eufyUsername === "undefined" ||
      typeof this.eufyPassword === "undefined" ||
      typeof this.mqttUrl === "undefined"
    ) {
      winston.error('Missing configuration, please check config.yml')
      throw new Error('Missing configuration, please check config.yml')
    }
  }
}

module.exports = new Config()
